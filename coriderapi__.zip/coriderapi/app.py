from flask import Flask, request, jsonify
from pymongo import MongoClient
from bson import ObjectId

app = Flask(__name__)
# app.config["MONGO_URI"] = "mongodb+srv://awanshahid1119:Access@cluster0.mongodb.net/corider?retryWrites=true&w=majority"
app.config["MONGO_URI"] = "mongodb://awanshahid1119:Access@cluster0-shard-00-00.mongodb.net:27017,cluster0-shard-00-01.mongodb.net:27017,cluster0-shard-00-02.mongodb.net:27017/corider?ssl=true&replicaSet=atlas-abc123-shard-0&authSource=admin&retryWrites=true&w=majority"

app.config["MONGO_DB_NAME"] = "corider"

client = MongoClient(app.config["MONGO_URI"])
db = client[app.config["MONGO_DB_NAME"]]
users_collection = db['users']
@app.route('/', methods=['GET'])
def home():
    return jsonify({"message": "Welcome to the User Management API!", "available_endpoints": ["/users", "/users/<id>"]})


@app.route('/users', methods=['GET'])
def get_users():
    users = list(users_collection.find({}))
    print(users)
    for user in users:
        user["_id"] = str(user["_id"])
    return jsonify(users)

@app.route('/users/<id>', methods=['GET'])
def get_user(id):
    user = users_collection.find_one({"_id": ObjectId(id)})
    if user:
        user["_id"] = str(user["_id"])
        return jsonify(user)
    return jsonify({"error": "User not found"}), 404

@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()
    result = users_collection.insert_one(data)
    return jsonify({"id": str(result.inserted_id)})

@app.route('/users/<id>', methods=['PUT'])
def update_user(id):
    data = request.get_json()
    users_collection.update_one({"_id": ObjectId(id)}, {"$set": data})
    return jsonify({"result": "User updated"})

@app.route('/users/<id>', methods=['DELETE'])
def delete_user(id):
    users_collection.delete_one({"_id": ObjectId(id)})
    return jsonify({"result": "User deleted"})

if __name__ == "__main__":
    app.run(debug=True)
